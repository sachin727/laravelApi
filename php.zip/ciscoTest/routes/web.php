<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});

Route::get('login', 'UserController@index');
Route::post('post-login', 'UserController@postLogin');
Route::get('dashboard', 'UserController@dashboard')->name('dashboard'); 
Route::get('logout', 'UserController@logout');
Route::group(['middleware' => 'auth'], function() {
    Route::get('create', 'SapController@create')->name('create');
    Route::post('create', 'SapController@save')->name('create');
    Route::get('sapid-exist/{name}', 'SapController@checkDuplicateByName')->name('check_duplicate_by_sapid');

    Route::get('edit/{id}', 'SapController@edit')->name('edit');
    Route::post('update/{id}', 'SapController@update')->name('update');
 
    Route::get('delete/{id}', 'SapController@delete')->name('delete');
});