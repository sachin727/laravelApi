<?php echo $__env->make('sap.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<div class="container">
    <div class="card mt-4"> 
            <?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			<?php endif; ?>
		   <?php if($message = Session::get('success')): ?>
		   <div class="alert alert-success alert-block">
			<button type="button" class="close" data-dismiss="alert">×</button>
				   <strong><?php echo e($message); ?></strong>
		   </div>
		   <?php endif; ?>
        <div class="card-body">
            <a href="<?php echo e(route('create')); ?>" class="btn btn-success float-right">Add</a> 
    <div class="panel panel-default">
    <div class="panel-heading">
     <h3 class="panel-title">Sap Data</h3>
    </div>
    <div class="panel-body">
     <div class="table-responsive">
      <table class="table table-striped table-bordered table-hover sapListing">
       <tr>
	    <th>Id</th>
        <th>SapId</th>
        <th>HostName</th>
        <th>LoopBack</th>
        <th>Mac Address</th>
        <th>Action</th>
               </tr>
			   
		<?php if(count($sap)>0): ?>	 
		<?php $i = 1; ?>			
       <?php $__currentLoopData = $sap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
	    <td><?php echo e($i++); ?></td>
        <td><?php echo e($c->sapid); ?></td>
        <td><?php echo e($c->hostname); ?></td>
        <td><?php echo e($c->loopback); ?></td>
        <td><?php echo e($c->macaddress); ?></td>
        <td><a href="<?php echo e(route('edit', $c->id)); ?>">Edit</a> | <a href="<?php echo e(route('delete', $c->id)); ?>" onclick="return confirm('Are you sure you want to delete this item')">Delete</a></td>
       </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	   <?php else: ?>
		<tr><td colspan="6" align="center">Records Not Found!</td></tr>   
	   <?php endif; ?>
      </table>
     </div>
    </div>
    </div>
    </div>
</div>

</div>
    
</body>
</html> 
<script src="<?php echo e(URL::asset('js/common.js')); ?>" ></script> 

<?php
    define("WIDTH", 300);
    define("HEIGHT", 300);

    $img = imagecreate(WIDTH,HEIGHT);
    $bg = $white = imagecolorallocate($img, 0xFF, 0xFF, 0xFF);
    $black = imagecolorallocate($img, 0, 0, 0);

    $center_x = (int)WIDTH/2;
    $center_y = (int)HEIGHT/2;
    imagerectangle($img, 0, 0, WIDTH-1, HEIGHT-1, $black);
    imagefilledarc($img,
                   $center_x,
                   $center_y,
                   WIDTH/2,
                   HEIGHT/2,
                   0,
                   90,
                   $black,
                   IMG_ARC_PIE);

    header("Content-Type: image/png");
    imagepng($img);

?><?php /**PATH C:\xampp\htdocs\cisco\larapassport\resources\views/sap/index.blade.php ENDPATH**/ ?>