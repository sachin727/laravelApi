<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\Sap; 
use Illuminate\Support\Facades\Auth; 
use Validator; 
use Redirect,Response;
use Session;

class SapController extends Controller 
{
    public $successStatus = 200;
    
    public function create() {
    try {    
         
      if(Auth::check()){
		 
        return view('sap.create');
      }
       return Redirect::to("login")->withSuccess('Opps! You do not have access');
    } catch (\Exception $e) {
        \Log::error($e);
        return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
    }
    }

    public function save(Request $request) { 
    try{    
        $validator = Validator::make($request->all(), 
                    [ 
                    'sapid' => 'required',
                    'hostname' => 'required',
                    'loopback' => 'required',    
                    ]);   
        if ($validator->fails()) {          
            return response()->json(['error'=>$validator->errors()], 401);
        }    
        $input                  = $request->all();  
        $localIP                = getHostByName(getHostName());
        $input['user_id']       =  Auth::user()->id;
        $input['macaddress']   = $localIP;
        
        $sap = Sap::create($input);     
        return Redirect::to("dashboard")->withSuccess('Create Record Successfully'); 
    } catch (\Exception $e) {
        \Log::error($e);
        return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
    }
    }
    
    public function edit(Request $request) {
        try {    
            
          if(Auth::check()){
             $sap = Sap::where('id', $request->id)->first();
            return view('sap.create', ['sap' => $sap]);
          }
           return Redirect::to("login")->withSuccess('Opps! You do not have access');
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
        }
        }
    
        public function update(Request $request) { 
        try{
            $validator = Validator::make($request->all(), 
                        [ 
                        'sapid' => 'required',
                        'hostname' => 'required',
                        'loopback' => 'required',    
                        ]);   
            if ($validator->fails()) {          
                return response()->json(['error'=>$validator->errors()], 401);
            }    
            $input                = $request->all();  
            $localIP              = getHostByName(getHostName()); 
            $input['id']          = $request->id;
            $input['macaddress']  = $localIP;
            unset($input['_token']);
            $sap = Sap::where('id', $input['id'])->update($input);     
            return Redirect::to("dashboard")->withSuccess('Update Record Successfully'); 
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
        }
        }
     
    public function checkDuplicateByName(Request $request) {
        try {
              
            $id = $request->id;
            if($id) {
                $counterpart = Sap::where('id', $id)->where('sapid', $request->name)->first();
            } else {
                $counterpart = Sap::where('sapid', $request->name)->first();
            }   
            if ($counterpart != null) {
                return response()->json(['error' => "SapId already exisit with the same Id"]);
            }

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['error' => "Some error occured"]);
        }
    }


    /*
     *Delet sap
     */
    public function delete(Request $request) {
        try { 
            $id = $request->id;
            $result = Sap::where('id', $id)->delete();
            
            return Redirect::to("dashboard")->withSuccess('Delete Record Successfully'); 
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['error' => 'some error occured to delete']);
        }        
    } 
} 