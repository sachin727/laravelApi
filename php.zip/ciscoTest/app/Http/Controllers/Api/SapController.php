<?php
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\Sap; 
use Illuminate\Support\Facades\Auth; 
use Validator; 
use Redirect,Response;
use Session;

class SapController extends Controller 
{
    public $successStatus = 200;
    
    public function create() {
    try {    
         
        if(Auth::check()){
		 
            if(!empty(Auth::check())){
                return response()->json(['success'=>true, 'message'=>"get Record Successfully.",'data'=>Auth::check() ], 200);
            }else{
                return response()->json(['success'=>false, 'message'=>"Unable to get Record !"], 200);
            } 
        }
       return Redirect::to("login")->withSuccess('Opps! You do not have access');
    } catch (\Exception $e) {
        \Log::error($e);
        return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
    }
    }

    public function save(Request $request) { 
    try{     
        if(Auth::check()) {

            $validator = Validator::make($request->all(), 
                        [ 
                        'sapid' => 'required',
                        'hostname' => 'required',
                        'loopback' => 'required',    
                        ]);   
            if ($validator->fails()) {          
                return response()->json(['error'=>$validator->errors()], 401);
            }    
            $input                  = $request->all();  
            $localIP                = getHostByName(getHostName());
            $input['user_id']       =  Auth::user()->id;
            $input['macaddress']   = $localIP;
            
            $sap = Sap::create($input);     
            if(!empty($sap)){
                return response()->json(['success'=>true, 'message'=>"Create Record Successfully.",'data'=>$sap ], 200);
            }else{
                return response()->json(['success'=>false, 'message'=>"Unable to Create Record !"], 200);
            }    
        }
        return Redirect::to("login")->withSuccess('Opps! You do not have access');
    } catch (\Exception $e) {
        \Log::error($e);
        return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
    }
    }
    
    public function edit(Request $request) {
        try {    
            
          if(Auth::check()){
                $sap = Sap::where('id', $request->id)->first(); 

                if(!empty($sap)){
                    return response()->json(['success'=>true, 'message'=>"edit Record Successfully.",'data'=>$sap ], 200);
                }else{
                    return response()->json(['success'=>false, 'message'=>"Unable to edit Record !"], 200);
                }    
          }
           return Redirect::to("login")->withSuccess('Opps! You do not have access');
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
        }
        }
    
        public function update(Request $request) { 
        try{
            $user =Auth::user()->token();  
            if(!empty($user)){

                $validator = Validator::make($request->all(), 
                            [ 
                            'sapid' => 'required',
                            'hostname' => 'required',
                            'loopback' => 'required',    
                            ]);   
                if ($validator->fails()) {          
                    return response()->json(['error'=>$validator->errors()], 401);
                }    
                $input                = $request->all();  
                $localIP              = getHostByName(getHostName()); 
                $input['id']          = $request->id;
                $input['macaddress']  = $localIP;
                unset($input['_token']);
                $sap = Sap::where('id', $input['id'])->update($input);    

                if(!empty($sap)){
                    return response()->json(['success'=>true, 'message'=>"Update Record Successfully.",'data'=>$sap ], 200);
                }else{
                    return response()->json(['success'=>false, 'message'=>"Unable to Update Record !"], 200);
                }
            }else{
                return response()->json(['success'=>false, 'message'=>"User Not Found !"], 200);
            }    
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
        }
        }
     
    public function checkDuplicateByName(Request $request) {
        try {
              
            $id = $request->id;
            if($id) {
                $counterpart = Sap::where('id', $id)->where('sapid', $request->name)->first();
            } else {
                $counterpart = Sap::where('sapid', $request->name)->first();
            }   
            if ($counterpart != null) {
                return response()->json(['error' => "SapId already exisit with the same Id"]);
            }

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['error' => "Some error occured"]);
        }
    }


    /*
     *Delet sap
     */
    public function delete(Request $request) {
        try { 
            $user =Auth::user()->token();  
            if(!empty($user)){

                $validator = Validator::make($request->all(), 
                            [ 
                            'id' => 'required',    
                            ]);   
                if ($validator->fails()) {          
                    return response()->json(['error'=>$validator->errors()], 401);
                } 

                $id = $request->id; 
                $result = Sap::where('id', $id)->delete();
                
                if(!empty($result)){
                    return response()->json(['success'=>true, 'message'=>"Delete Record successfully.",'data'=>$result ], 200);
                }else{
                    return response()->json(['success'=>false, 'message'=>"Unable to Delete Record !"], 200);
                }
            }else{
                return response()->json(['success'=>false, 'message'=>"User Not Found !"], 200);
            }    
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['error' => 'some error occured to delete']);
        }        
    }
 
    public function getData() {  
        try {   
            $user =Auth::user()->token(); 
            
            if(!empty($user)){
                $sap = Sap::all();
                if(!empty($sap)){
                    return response()->json(['success'=>true, 'message'=>"get all Record successfully.",'data'=>$sap ], 200);
                }else{
                    return response()->json(['success'=>false, 'message'=>"Unable to get all Record !"], 200);
                } 
            }else{
                return response()->json(['success'=>false, 'message'=>"User Not Found !"], 200);
            }    
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
        }
    }
    
    public function getDataBySap(Request $request) {  
        try {   
            $user =Auth::user()->token(); 
            
            if(!empty($user)){
                
                $validator = Validator::make($request->all(), 
                            [ 
                            'sapid' => 'required',    
                            ]);   
                if ($validator->fails()) {          
                    return response()->json(['error'=>$validator->errors()], 401);
                } 
                $sapid = $request->sapid;

                $sap = Sap::where('sapid', $sapid)->first();
                if(!empty($sap)){
                    return response()->json(['success'=>true, 'message'=>"get Record successfully.",'data'=>$sap ], 200);
                }else{
                    return response()->json(['success'=>false, 'message'=>"Unable to get Record !"], 200);
                } 
            }else{
                return response()->json(['success'=>false, 'message'=>"User Not Found !"], 200);
            }    
        } catch (\Exception $e) {
            \Log::error($e);
            return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
        }
    }
} 