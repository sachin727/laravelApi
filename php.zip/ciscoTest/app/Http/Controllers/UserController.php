<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use Validator,Redirect,Response;
Use App\User;
Use App\Sap;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Session;
 
class UserController extends Controller
{
 
    public function index()
    {
        return view('login');
    }  
 
    public function postLogin(Request $request) { 
    try{    
        request()->validate([
        'email' => 'required',
        'password' => 'required',
        ]);
 
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            // Authentication passed...
            return redirect()->intended('dashboard');
        }
        return Redirect::to("login")->withSuccess('Oppes! You have entered invalid credentials');
    } catch (\Exception $e) {
        \Log::error($e);
        return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
    }
    }

    public function dashboard() {
    try{    

        if(Auth::check()){
		    $sap = Sap::orderBy('created_at','DESC')->get();
            return view('sap.index', ['sap' => $sap]);
        }
        return Redirect::to("login")->withSuccess('Opps! You do not have access');
    } catch (\Exception $e) {
        \Log::error($e);
        return response()->json(['success' => false,'message'=>"Something wrong, Please try again."],200);
    }
    }
 
    public function logout() {
        Session::flush();
        Auth::logout();
        return Redirect('login');
    }

}