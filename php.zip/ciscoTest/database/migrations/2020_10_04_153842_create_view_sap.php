<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateViewSap extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::Statement('create or replace view `view_saps` as select `saps`.`id` AS `id`, `saps`.`sapid` AS `sapid`, `saps`.`hostname` AS `hostname`, `saps`.`loopback` AS `loopback`, `saps`.`macaddress` AS `macaddress` from `laravelapi`.`saps`;');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
