<?php

 use Illuminate\Database\Seeder;
 use Illuminate\Database\Eloquent\Model;
    
    
class SapTableSeeder extends Seeder
{
    
    public function run()
    {        
        for($i = 0; $i <= 9; $i++) {
        $sap = array( 
                array(
                    'user_id'    => null,
                    'sapid'      => 'abcd1234'.$i,
                    'hostname'   => 'group1'.$i,
                    'loopback'   => '127.0.0'.$i,
                    'macaddress' => '127.0.0'.$i,
                    'created_at' => \Carbon\Carbon::now(),
                    'updated_at' => \Carbon\Carbon::now()                      
                 ) 
        ); 
        DB::table('view_saps')->insert($sap);
        }    
    } 
    
}
?>