@include('sap.header')
    
<div class="container">
    <div class="card mt-4"> 
            @if($errors->any())
				<div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
					<ul>
						@foreach ($errors->all() as $error)
							<li>{{ $error }}</li>
						@endforeach
					</ul>
				</div>
			@endif
		   @if($message = Session::get('success'))
		   <div class="alert alert-success alert-block">
			<button type="button" class="close" data-dismiss="alert">×</button>
				   <strong>{{ $message }}</strong>
		   </div>
		   @endif
        <div class="card-body">
        <a href="{{ route('dashboard') }}" class="btn btn-success float-right">Back</a>
    <div class="panel panel-default">
    <div class="panel-heading">
     <h3 class="panel-title">
     
     @if(isset($sap) && !empty($sap))
     Update Sap Data
     @else
     Create Sap Data
     @endif
     </h3>
     
    </div>
    <div class="panel-body">
     <div class="table-responsive">
     <form action="{{ (isset($sap) && !empty($sap->id)) ? url('update', $sap->id) : url('create') }}" method="POST" id="Form">
            {{ csrf_field() }}
            <div class="row col-md-12">
                <div class="col-md-4">
                    <div class="form-label-group">
                    <label for="sapid">Sap Id</label>
                    <input type="text" id="sapid" name="sapid" maxlength="18" onChange="isNameExist(this.value, {{(isset($sap) && !empty($sap->id)) ?$sap->id : ''}})" class="form-control" value="{{ (isset($sap) && !empty($sap->sapid)) ? $sap->sapid : '' }}" placeholder="Sap Id" required autofocus>
                    <div id="duplicateSapidErrorDivId"></div>
                    @if ($errors->has('sapid'))
                    <span class="error">{{ $errors->first('sapid') }}</span>
                    @endif       
                    </div> 
                </div> 

                <div class="col-md-4">
                    <div class="form-label-group">
                    <label for="hostname">HostName</label>
                    <input type="text" name="hostname" id="hostname" maxlength="14" value="{{ (isset($sap) && !empty($sap->hostname)) ? $sap->hostname : '' }}" class="form-control" required placeholder="HostName" >
                    @if ($errors->has('hostname'))
                    <span class="error">{{ $errors->first('hostname') }}</span>
                    @endif    
                    </div> 
                </div> 
             
                <div class="col-md-4">
            <div class="form-label-group">
            <label for="loopback">LoopBack</label>
            <input type="text" name="loopback" id="loopback" maxlength="45" value="{{ (isset($sap) && !empty($sap->loopback)) ? $sap->loopback : '' }}" class="form-control" required placeholder="LoopBack" >
            @if ($errors->has('loopback'))
            <span class="error">{{ $errors->first('loopback') }}</span>
            @endif    
            </div> 
            </div> 
 
            </div> 
            </div>
            <div class="row col-md-12">&nbsp;</div>
            <div class="row col-md-12">
            <div class="col-md-3"> 
            <button class="btn btn-lg btn-primary btn-block text-uppercase font-weight-bold mb-2" id="submit" type="submit">Submit</button>
            </div>
            <div class="col-md-9"></div>
            </div>
            </form> 
     </div>
    </div>
    </div>
    </div>
</div>

</div>
    
</body>
</html> 

<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="{{URL::asset('js/common.js')}}" ></script>
<script>   
   var checkDuplicateBySapid = "{{ route('check_duplicate_by_sapid', '-id-') }}";  
</script>