@include('sap.header')
    
<div class="container">
    <div class="card mt-4"> 
            @if($errors->any())
				<div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
					<ul>
						@foreach ($errors->all() as $error)
							<li>{{ $error }}</li>
						@endforeach
					</ul>
				</div>
			@endif
		   @if($message = Session::get('success'))
		   <div class="alert alert-success alert-block">
			<button type="button" class="close" data-dismiss="alert">×</button>
				   <strong>{{ $message }}</strong>
		   </div>
		   @endif
        <div class="card-body">
            <a href="{{ route('create') }}" class="btn btn-success float-right">Add</a> 
    <div class="panel panel-default">
    <div class="panel-heading">
     <h3 class="panel-title">Sap Data</h3>
    </div>
    <div class="panel-body">
     <div class="table-responsive">
      <table class="table table-striped table-bordered table-hover sapListing">
       <tr>
	    <th>Id</th>
        <th>SapId</th>
        <th>HostName</th>
        <th>LoopBack</th>
        <th>Mac Address</th>
        <th>Action</th>
               </tr>
			   
		@if(count($sap)>0)	 
		@php $i = 1; @endphp			
       @foreach($sap as $c)
       <tr>
	    <td>{{ $i++ }}</td>
        <td>{{ $c->sapid }}</td>
        <td>{{ $c->hostname }}</td>
        <td>{{ $c->loopback }}</td>
        <td>{{ $c->macaddress }}</td>
        <td><a href="{{ route('edit', $c->id)}}">Edit</a> | <a href="{{ route('delete', $c->id)}}" onclick="return confirm('Are you sure you want to delete this item')">Delete</a></td>
       </tr>
       @endforeach
	   @else
		<tr><td colspan="6" align="center">Records Not Found!</td></tr>   
	   @endif
      </table>
     </div>
    </div>
    </div>
    </div>
</div>

</div>
    
</body>
</html> 
<script src="{{URL::asset('js/common.js')}}" ></script> 

<?php
    define("WIDTH", 300);
    define("HEIGHT", 300);

    $img = imagecreate(WIDTH,HEIGHT);
    $bg = $white = imagecolorallocate($img, 0xFF, 0xFF, 0xFF);
    $black = imagecolorallocate($img, 0, 0, 0);

    $center_x = (int)WIDTH/2;
    $center_y = (int)HEIGHT/2;
    imagerectangle($img, 0, 0, WIDTH-1, HEIGHT-1, $black);
    imagefilledarc($img,
                   $center_x,
                   $center_y,
                   WIDTH/2,
                   HEIGHT/2,
                   0,
                   90,
                   $black,
                   IMG_ARC_PIE);

    header("Content-Type: image/png");
    imagepng($img);

?>