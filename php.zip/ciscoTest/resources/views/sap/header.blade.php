<!DOCTYPE html>
<html>
<head>
<title>Sap</title> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" ></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" ></script>
<link rel="stylesheet" type="text/css" href="{{url('style.css')}}">
</head>
<div class="pull-right">Welcome {{ ucfirst(Auth()->user()->name) }}&nbsp;<a class="small" href="{{url('logout')}}">Logout</a></div>
<br><hr>
<body>