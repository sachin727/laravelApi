<?php
 return [
     /*for calling api urls*/
     'login'                            => 'login',
     'create'                           => 'create',
     'update'                           => 'update',
     'delete'                           => 'delete',
     'select'                           => 'select', 
 ];