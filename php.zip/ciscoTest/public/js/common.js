function isNameExist(sapId, id) {
    url = checkDuplicateBySapid.replace("-id-", sapId);

    if (id != undefined && id != "") {
        url = url + "&id=" + id;
    }
    $.ajax({
        url: url,
        type: "GET",
        success: function (data) {
            if (data.error) {
                $("#duplicateSapidErrorDivId")
                    .html(data.error)
                    .css("color", "red");
                $("#submit").prop("disabled", true);
            } else {
                $("#duplicateSapidErrorDivId").html("");
                $("#submit").prop("disabled", false);
            }
        },
    });
}
